"""Build the city-first land-cell geometry benchmark for La Coruna.

The benchmark deliberately avoids a final Voronoi partition. It creates:
1. an asymmetric city cell around La Coruna;
2. a western coastal/peninsular cell;
3. a compact southern interior cell;
4. an eastern interior cell.

All divisions are sequential cuts of the original province polygon. Shared
edges therefore come from the same geometry and coverage remains exact.
"""
from __future__ import annotations

import json
import math
from pathlib import Path

from shapely.geometry import LineString, Point, Polygon
from shapely.ops import split as shapely_split
from shapely.ops import unary_union

import build_cells_test as cell_tools


ROOT = Path(__file__).resolve().parents[2]
GEOMETRY_PATH = ROOT / "assets" / "map_geometry" / "provinces.json"
PROVINCES_PATH = ROOT / "assets" / "game_data" / "provinces.json"
CITIES_PATH = ROOT / "assets" / "province_cities_iberia.json"
OUT_PATH = ROOT / "assets" / "lacoruna_city_first_cells_preview.json"

PROVINCE_ID = "province:2848"
WORLD_PX = 8192.0
TARGET_AREA_KM2 = 2100.0
CITY_PROTECTION_RATIO = 0.32


# Normalized cut geometry (u, v) inside the province bbox.
# v grows southward because the source uses map pixel coordinates.
#
# The city boundary is intentionally asymmetric: it is neither a circle nor
# a smooth constant-radius arc. It gives the city a southern hinterland but
# does not create a separate narrow north-eastern strip.
CITY_CUT_UV = [
    (-0.10, 0.36),
    (0.17, 0.40),
    (0.29, 0.45),
    (0.41, 0.48),
    (0.54, 0.46),
    (0.68, 0.42),
    (0.80, 0.35),
    (1.10, 0.27),
]

# A neck-like cut separates the western coastal lobe. The route is not a
# straight vertical stripe: it follows the province's western indentation and
# then opens slightly towards the southern coast.
WEST_CUT_UV = [
    (0.16, 0.20),
    (0.17, 0.40),
    (0.25, 0.57),
    (0.30, 0.78),
    (0.34, 1.10),
]

# The final cut is diagonal and mildly irregular. It avoids a set of parallel
# north-south strips and yields two compact interior cells.
EAST_CUT_UV = [
    (0.60, 0.25),
    (0.60, 0.45),
    (0.56, 0.60),
    (0.62, 0.76),
    (0.68, 1.10),
]


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as file:
        return json.load(file)


def polygon_from_rings(rings: list) -> Polygon:
    poly = Polygon(rings[0], rings[1:])
    if not poly.is_valid:
        poly = poly.buffer(0)
    if poly.geom_type == "MultiPolygon":
        poly = max(poly.geoms, key=lambda part: part.area)
    if poly.is_empty:
        raise RuntimeError("empty province geometry")
    return poly


def polygon_parts(geom) -> list[Polygon]:
    if geom.is_empty:
        return []
    if geom.geom_type == "Polygon":
        return [geom]
    if geom.geom_type == "MultiPolygon":
        return list(geom.geoms)
    if geom.geom_type == "GeometryCollection":
        result: list[Polygon] = []
        for part in geom.geoms:
            result.extend(polygon_parts(part))
        return result
    return []


def rings_from_polygon(poly: Polygon) -> list:
    rings = [[[round(x, 2), round(y, 2)] for x, y in poly.exterior.coords]]
    for hole in poly.interiors:
        rings.append([[round(x, 2), round(y, 2)] for x, y in hole.coords])
    return rings


def bbox_from_ring(ring: list) -> list:
    xs = [point[0] for point in ring]
    ys = [point[1] for point in ring]
    return [min(xs), min(ys), max(xs), max(ys)]


def polygon_area_km2(rings: list) -> float:
    area = cell_tools.ring_area_km2_world_px(rings[0])
    for hole in rings[1:]:
        area -= cell_tools.ring_area_km2_world_px(hole)
    return max(area, 0.0)


def normalized_points(poly: Polygon, points_uv: list[tuple[float, float]]) -> list[tuple[float, float]]:
    minx, miny, maxx, maxy = poly.bounds
    width = maxx - minx
    height = maxy - miny
    return [
        (minx + u * width, miny + v * height)
        for u, v in points_uv
    ]


def split_by_normalized_line(
    poly: Polygon,
    points_uv: list[tuple[float, float]],
    label: str,
    reference_poly: Polygon | None = None,
) -> tuple[list[Polygon], list[tuple[float, float]]]:
    points = normalized_points(reference_poly or poly, points_uv)
    result = shapely_split(poly, LineString(points))
    pieces = [part.buffer(0) for part in polygon_parts(result) if part.area > 1e-8]
    if len(pieces) != 2:
        raise RuntimeError(f"{label} must produce exactly 2 pieces, got {len(pieces)}")
    return pieces, points


def get_province() -> tuple[dict, dict, Polygon]:
    province = next(
        item for item in load_json(PROVINCES_PATH)["provinces"]
        if item["id"] == PROVINCE_ID
    )
    geometry = next(
        item for item in load_json(GEOMETRY_PATH)["provinces"]
        if item["id"] == PROVINCE_ID
    )

    # Use the final province polygon itself as the source of truth.
    # The old benchmark clipped it through world_ocean and removed roughly
    # twelve percent of La Coruna's land area. Cell coverage must match the
    # province exactly; coastline rendering is a separate concern.
    province_poly = polygon_from_rings(geometry["rings"])
    return province, geometry, province_poly


def get_city() -> dict:
    for city in load_json(CITIES_PATH)["cities"]:
        if city.get("province") == "La Coruña":
            return city
    raise RuntimeError("La Coruna city marker not found")


def select_piece_containing(pieces: list[Polygon], point: Point, label: str) -> tuple[Polygon, Polygon]:
    containing = [piece for piece in pieces if piece.buffer(1e-7).contains(point)]
    if len(containing) != 1:
        raise RuntimeError(f"{label}: expected one piece containing the point, got {len(containing)}")
    selected = containing[0]
    other = next(piece for piece in pieces if piece is not selected)
    return selected, other


def build_cells(province_poly: Polygon, city_pos: tuple[float, float]):
    debug_lines: dict[str, list[list[float]]] = {}
    city_point = Point(city_pos)

    city_parts, city_line = split_by_normalized_line(province_poly, CITY_CUT_UV, "city cut")
    city_cell, southern_remainder = select_piece_containing(city_parts, city_point, "city cut")
    debug_lines["city_cut"] = [[round(x, 2), round(y, 2)] for x, y in city_line]

    west_parts, west_line = split_by_normalized_line(southern_remainder, WEST_CUT_UV, "west cut", province_poly)
    west = min(west_parts, key=lambda part: part.representative_point().x)
    interior = max(west_parts, key=lambda part: part.representative_point().x)
    debug_lines["west_cut"] = [[round(x, 2), round(y, 2)] for x, y in west_line]

    east_parts, east_line = split_by_normalized_line(interior, EAST_CUT_UV, "east cut", province_poly)
    east = max(east_parts, key=lambda part: part.representative_point().x)
    south = min(east_parts, key=lambda part: part.representative_point().x)
    debug_lines["east_cut"] = [[round(x, 2), round(y, 2)] for x, y in east_line]

    cells = [
        ("city", "Ла-Корунья — городская клетка", city_cell),
        ("west_coast", "Ла-Корунья — западная прибрежная", west),
        ("south_interior", "Ла-Корунья — южная внутренняя", south),
        ("east_interior", "Ла-Корунья — восточная внутренняя", east),
    ]
    return cells, debug_lines


def make_cell(province: dict, kind: str, name: str, poly: Polygon, source_poly: Polygon) -> dict:
    poly = poly.buffer(0)
    rings = rings_from_polygon(poly)
    brd_open, brd_boundary = cell_tools._split_border_chains(rings[0], source_poly.boundary)
    brd_open = cell_tools._trim_open_chains_to_land(brd_open, source_poly, source_poly)
    representative = poly.representative_point()
    centroid = poly.centroid
    return {
        "id": f"lacoruna_city_first:{kind}",
        "name": name,
        "province_id": province["id"],
        "legacy_province_id": province["legacy_id"],
        "region_id": province["region_id"],
        "cell_role": kind,
        "rings": rings,
        "brd_open": brd_open,
        "brd_boundary": brd_boundary,
        "bbox": bbox_from_ring(rings[0]),
        "center": [round(centroid.x, 2), round(centroid.y, 2)],
        "label_point": [round(representative.x, 2), round(representative.y, 2)],
        "area_km2": round(polygon_area_km2(rings), 1),
        "color_key": kind,
    }


def validate_coverage(province_poly: Polygon, cells) -> dict:
    polygons = [poly for _kind, _name, poly in cells]
    union = unary_union(polygons)
    missing = province_poly.difference(union).area
    extra = union.difference(province_poly).area
    overlap_area = sum(poly.area for poly in polygons) - union.area
    return {
        "missing_world_px2": round(missing, 9),
        "extra_world_px2": round(extra, 9),
        "overlap_world_px2": round(overlap_area, 9),
        "ok": missing < 1e-7 and extra < 1e-7 and abs(overlap_area) < 1e-7,
    }


def validate_cells(city_pos: tuple[float, float], cells) -> dict:
    city_point = Point(city_pos)
    city_cell = next(poly for kind, _name, poly in cells if kind == "city")
    areas = {}
    for kind, _name, poly in cells:
        rings = rings_from_polygon(poly)
        areas[kind] = round(polygon_area_km2(rings), 1)

    return {
        "city_inside_city_cell": city_cell.buffer(1e-7).contains(city_point),
        "cell_areas_km2": areas,
        "min_area_km2": min(areas.values()),
        "max_area_km2": max(areas.values()),
        "max_to_min_area_ratio": round(max(areas.values()) / min(areas.values()), 3),
    }


def main() -> None:
    province, geometry, province_poly = get_province()
    city = get_city()
    city_pos = tuple(city["pos"])

    cells_geom, debug_lines = build_cells(province_poly, city_pos)
    coverage = validate_coverage(province_poly, cells_geom)
    quality = validate_cells(city_pos, cells_geom)

    target_radius_km = math.sqrt(TARGET_AREA_KM2 / math.pi)
    payload = {
        "schema_version": 2,
        "kind": "lacoruna_city_first_preview",
        "world_px": WORLD_PX,
        "source": {
            "geometry": str(GEOMETRY_PATH.relative_to(ROOT)).replace("\\", "/"),
            "city": str(CITIES_PATH.relative_to(ROOT)).replace("\\", "/"),
            "method": "city_first_recursive_natural_cuts",
        },
        "debug": {
            "province_id": province["id"],
            "source_area_km2": geometry.get("area_km2"),
            "city": city,
            "target_area_km2": TARGET_AREA_KM2,
            "city_protection_radius_km": round(target_radius_km * CITY_PROTECTION_RATIO, 2),
            "coverage": coverage,
            "quality": quality,
            "cut_lines": debug_lines,
        },
        "cells": [
            make_cell(province, kind, name, poly, province_poly)
            for kind, name, poly in cells_geom
        ],
    }

    with OUT_PATH.open("w", encoding="utf-8") as file:
        json.dump(payload, file, ensure_ascii=False, separators=(",", ":"))

    print(f"wrote {OUT_PATH.relative_to(ROOT)}")
    print(f"cells: {len(payload['cells'])}")
    for cell in payload["cells"]:
        print(f"{cell['id']}: {cell['area_km2']:.1f} km2")
    print(f"coverage ok: {coverage['ok']}")
    print(f"city inside: {quality['city_inside_city_cell']}")
    print(f"area ratio: {quality['max_to_min_area_ratio']}")


if __name__ == "__main__":
    main()
