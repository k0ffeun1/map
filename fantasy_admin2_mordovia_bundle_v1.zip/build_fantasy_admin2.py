#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fantasy Admin-2 generator for Natural Earth Admin-1.

Pipeline:
  Natural Earth Admin-1 -> regional profile resolver -> cell count ->
  warped centroidal Voronoi + marker watershed candidate -> connectivity cleanup ->
  Rasterio polygonize -> Shapely coverage_simplify -> GeoPackage/GeoJSON + CSV report.

Important project rule: relief/cities are NOT used as generation inputs here.
Relief factor is fixed to 1.0. Admin-1 geometry, profile target area, coast/shape
complexity and deterministic procedural fields drive the result.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
import warnings
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path

import geopandas as gpd
import networkx as nx
import numpy as np
import rasterio.features
from affine import Affine
from pyproj import CRS, Transformer
from scipy import ndimage
from scipy.spatial import cKDTree
from shapely import STRtree, coverage_is_valid, coverage_simplify, make_valid
from shapely.geometry import GeometryCollection, MultiPolygon, Polygon, shape
from shapely.ops import transform as shp_transform, unary_union
from skimage.segmentation import find_boundaries, watershed

warnings.filterwarnings("ignore", category=RuntimeWarning)


@dataclass(frozen=True)
class Profile:
    region: str
    macroregion: str
    continent: str
    profile: str
    target_km2: float
    min_cells: int
    max_cells: int
    historical_density: float
    geo_complexity: float
    note: str = ""


def norm_text(s: object) -> str:
    if s is None:
        return ""
    s = str(s).strip().lower()
    s = s.replace("ё", "е")
    s = re.sub(r"[^a-zа-я0-9]+", " ", s, flags=re.I)
    return re.sub(r"\s+", " ", s).strip()


def stable_seed(*parts: object) -> int:
    raw = "|".join(str(x) for x in parts).encode("utf-8")
    return int.from_bytes(hashlib.blake2b(raw, digest_size=8).digest(), "little") & 0x7FFFFFFF


def load_profiles(path: str):
    obj = json.loads(Path(path).read_text(encoding="utf-8"))
    profiles = [Profile(**p) for p in obj["profiles"]]
    by_region = {norm_text(p.region): p for p in profiles}
    by_macro = defaultdict(list)
    for p in profiles:
        by_macro[norm_text(p.macroregion)].append(p)
    return profiles, by_region, by_macro


def macro_median(by_macro, macro: str) -> Profile:
    arr = by_macro[norm_text(macro)]
    if not arr:
        raise KeyError(macro)
    arr = sorted(arr, key=lambda p: p.target_km2)
    return arr[len(arr)//2]


def choose_region(by_region, name: str) -> Profile:
    return by_region[norm_text(name)]


# Country groups for broad resolver. More heterogeneous countries are handled below.
COUNTRY_MACRO = {
    # Europe
    "Belgium":"Низкие земли", "Netherlands":"Низкие земли", "Luxembourg":"Низкие земли",
    "United Kingdom":"Британские острова", "Ireland":"Британские острова", "Isle of Man":"Британские острова",
    "Guernsey":"Британские острова", "Jersey":"Британские острова",
    "France":"Франция", "Monaco":"Франция",
    "Italy":"Италия", "San Marino":"Италия", "Vatican":"Италия",
    "Germany":"Центральная Европа", "Austria":"Центральная Европа", "Switzerland":"Центральная Европа",
    "Czech Republic":"Центральная Европа", "Slovakia":"Центральная Европа", "Hungary":"Центральная Европа",
    "Romania":"Центральная Европа", "Liechtenstein":"Центральная Европа",
    "Denmark":"Скандинавия", "Sweden":"Скандинавия", "Norway":"Скандинавия", "Finland":"Скандинавия",
    "Aland":"Скандинавия", "Faroe Islands":"Скандинавия", "Iceland":"Скандинавия",
    "Poland":"Восточная Европа", "Lithuania":"Восточная Европа", "Latvia":"Восточная Европа",
    "Estonia":"Восточная Европа", "Belarus":"Восточная Европа", "Ukraine":"Восточная Европа", "Moldova":"Восточная Европа",
    "Slovenia":"Балканы", "Croatia":"Балканы", "Bosnia and Herzegovina":"Балканы", "Republic of Serbia":"Балканы",
    "Kosovo":"Балканы", "Montenegro":"Балканы", "Albania":"Балканы", "Macedonia":"Балканы", "Bulgaria":"Балканы",
    "Greece":"Балканы", "Cyprus":"Балканы", "Northern Cyprus":"Балканы",
    "Spain":"Иберия", "Portugal":"Иберия", "Andorra":"Иберия", "Gibraltar":"Иберия",
    # West Asia / Central Asia
    "Turkey":"Малая Азия", "Armenia":"Кавказ", "Georgia":"Кавказ", "Azerbaijan":"Кавказ",
    "Israel":"Левант", "West Bank":"Левант", "Gaza Strip":"Левант", "Lebanon":"Левант", "Jordan":"Левант", "Syria":"Левант",
    "Iraq":"Месопотамия", "Kuwait":"Месопотамия",
    "Saudi Arabia":"Аравия", "Yemen":"Аравия", "Oman":"Аравия", "United Arab Emirates":"Аравия", "Qatar":"Аравия", "Bahrain":"Аравия",
    "Iran":"Иран", "Kazakhstan":"Центральная Азия", "Uzbekistan":"Центральная Азия", "Turkmenistan":"Центральная Азия",
    "Kyrgyzstan":"Центральная Азия", "Tajikistan":"Центральная Азия", "Baykonur Cosmodrome":"Центральная Азия",
    "Mongolia":"Монголия", "North Korea":"Корея", "South Korea":"Корея", "Japan":"Япония",
    "Pakistan":"Индостан", "Afghanistan":"Индостан",
    "Myanmar":"Юго-Восточная Азия", "Thailand":"Юго-Восточная Азия", "Laos":"Юго-Восточная Азия", "Cambodia":"Юго-Восточная Азия",
    "Vietnam":"Юго-Восточная Азия", "Malaysia":"Юго-Восточная Азия", "Singapore":"Юго-Восточная Азия", "Brunei":"Юго-Восточная Азия",
    "Philippines":"Юго-Восточная Азия", "East Timor":"Индонезия", "Indonesia":"Индонезия",
    # North Africa
    "Egypt":"Северная Африка", "Libya":"Северная Африка", "Tunisia":"Северная Африка", "Algeria":"Северная Африка",
    "Morocco":"Северная Африка", "Western Sahara":"Северная Африка",
    # West Africa
    "Mauritania":"Западная Африка", "Senegal":"Западная Африка", "Gambia":"Западная Африка", "Mali":"Западная Африка",
    "Burkina Faso":"Западная Африка", "Niger":"Западная Африка", "Nigeria":"Западная Африка", "Benin":"Западная Африка",
    "Togo":"Западная Африка", "Ghana":"Западная Африка", "Ivory Coast":"Западная Африка", "Liberia":"Западная Африка",
    "Sierra Leone":"Западная Африка", "Guinea":"Западная Африка", "Guinea Bissau":"Западная Африка", "Cape Verde":"Западная Африка",
    # Central Africa
    "Chad":"Центральная Африка", "Cameroon":"Центральная Африка", "Central African Republic":"Центральная Африка",
    "Equatorial Guinea":"Центральная Африка", "Gabon":"Центральная Африка", "Republic of the Congo":"Центральная Африка",
    "Democratic Republic of the Congo":"Центральная Африка", "Angola":"Центральная Африка", "Sao Tome and Principe":"Центральная Африка",
    # East Africa
    "Sudan":"Восточная Африка", "S. Sudan":"Восточная Африка", "Eritrea":"Восточная Африка", "Ethiopia":"Восточная Африка",
    "Djibouti":"Восточная Африка", "Somalia":"Восточная Африка", "Somaliland":"Восточная Африка", "Kenya":"Восточная Африка",
    "Uganda":"Восточная Африка", "Rwanda":"Восточная Африка", "Burundi":"Восточная Африка", "United Republic of Tanzania":"Восточная Африка",
    # Southern Africa
    "Zambia":"Южная Африка", "Zimbabwe":"Южная Африка", "Malawi":"Южная Африка", "Mozambique":"Южная Африка",
    "Botswana":"Южная Африка", "Namibia":"Южная Африка", "South Africa":"Южная Африка", "Lesotho":"Южная Африка", "Swaziland":"Южная Африка",
    "Madagascar":"Мадагаскар",
    # North America
    "United States of America":"Центр Северной Америки", "Canada":"Канада", "Greenland":"Канада", "Mexico":"Мексика",
    "Guatemala":"Центральная Америка", "Belize":"Центральная Америка", "Honduras":"Центральная Америка", "El Salvador":"Центральная Америка",
    "Nicaragua":"Центральная Америка", "Costa Rica":"Центральная Америка", "Panama":"Центральная Америка",
    # Caribbean / islands
    "Cuba":"Карибы", "Haiti":"Карибы", "Dominican Republic":"Карибы", "Jamaica":"Карибы", "Puerto Rico":"Карибы",
    "The Bahamas":"Карибы", "Trinidad and Tobago":"Карибы", "Barbados":"Карибы", "Grenada":"Карибы",
    "Antigua and Barbuda":"Карибы", "Dominica":"Карибы", "Saint Lucia":"Карибы", "Saint Vincent and the Grenadines":"Карибы",
    "Saint Kitts and Nevis":"Карибы", "British Virgin Islands":"Карибы", "United States Virgin Islands":"Карибы",
    "Cayman Islands":"Карибы", "Turks and Caicos Islands":"Карибы", "Anguilla":"Карибы", "Montserrat":"Карибы",
    "Aruba":"Карибы", "Curaçao":"Карибы", "Sint Maarten":"Карибы", "Saint Martin":"Карибы", "Saint Barthelemy":"Карибы",
    "Caribbean Netherlands":"Карибы", "Bermuda":"Карибы", "US Naval Base Guantanamo Bay":"Карибы",
    # South America
    "Colombia":"Северные Анды", "Venezuela":"Север Южной Америки", "Guyana":"Север Южной Америки", "Suriname":"Север Южной Америки",
    "Ecuador":"Центральные Анды", "Peru":"Центральные Анды", "Bolivia":"Центральные Анды", "Brazil":"Бразилия",
    "Paraguay":"Южная Америка", "Uruguay":"Южная Америка", "Argentina":"Южная Америка", "Chile":"Южные Анды",
    "Falkland Islands":"Южная Америка", "South Georgia and the Islands":"Южная Америка",
    # Oceania
    "Australia":"Австралия", "New Zealand":"Новая Зеландия", "Papua New Guinea":"Меланезия", "New Caledonia":"Меланезия",
    "Solomon Islands":"Островная Океания", "Vanuatu":"Островная Океания", "Fiji":"Островная Океания", "Samoa":"Островная Океания",
    "American Samoa":"Островная Океания", "Tonga":"Островная Океания", "Cook Islands":"Островная Океания", "Niue":"Островная Океания",
    "French Polynesia":"Островная Океания", "Kiribati":"Островная Океания", "Tuvalu":"Островная Океания",
    "Federated States of Micronesia":"Островная Океания", "Marshall Islands":"Островная Океания", "Palau":"Островная Океания",
    "Guam":"Островная Океания", "Northern Mariana Islands":"Островная Океания", "Nauru":"Островная Океания",
    "Wallis and Futuna":"Островная Океания", "Pitcairn Islands":"Островная Океания", "Norfolk Island":"Островная Океания",
}


def resolve_profile(row, by_region, by_macro):
    """Return (Profile, confidence, rule_name)."""
    country = str(row.get("admin") or "")
    name = str(row.get("name_en") or row.get("name") or "")
    region = str(row.get("region") or "")
    sub = str(row.get("region_sub") or "")
    lat = float(row.get("latitude") if row.get("latitude") is not None else row.geometry.representative_point().y)
    lon = float(row.get("longitude") if row.get("longitude") is not None else row.geometry.representative_point().x)
    n = norm_text(name)
    r = norm_text(region)
    s = norm_text(sub)

    def R(x, conf="high", rule="specific"):
        try:
            return choose_region(by_region, x), conf, rule
        except KeyError:
            return None

    # RUSSIA: Natural Earth has useful federal district / economic region fields.
    if country == "Russia":
        if n in {"kamchatka", "chukchi autonomous okrug", "chukotka", "magadan"}:
            return R("Камчатка и Чукотка", "high", "russia_far_east_extreme")
        if n in {"sakha", "sakha yakutia", "yakutia"} or lon > 125 and lat > 60:
            return R("Якутия", "high", "russia_yakutia")
        if r == "far eastern":
            return R("Амур и Приморье", "high", "russia_far_east")
        if r == "urals" and s == "west siberian":
            return R("Западносибирская тайга", "medium", "russia_west_siberia")
        if r == "urals":
            return R("Урал", "high", "russia_urals")
        if r == "siberian":
            if lon >= 108:
                return R("Забайкалье", "high", "russia_transbaikalia")
            if 98 <= lon < 108:
                return R("Прибайкалье", "medium", "russia_baikal")
            if lat >= 60:
                return R("Центральная сибирская тайга", "medium", "russia_central_taiga")
            if lon < 90 and lat >= 55:
                return R("Западносибирская тайга", "medium", "russia_west_taiga")
            return R("Южная Сибирь", "medium", "russia_south_siberia")
        if r == "northwestern" and s == "northern":
            return R("Русский Север", "high", "russia_north")
        if r == "northwestern":
            return R("Северо-Западная Россия", "high", "russia_northwest")
        if r == "central":
            return R("Центральная Россия", "high", "russia_central")
        if r == "volga" and s == "north caucasus":
            return R("Южная Россия и Предкавказье", "high", "russia_south")
        if r == "volga":
            return R("Поволжье", "high", "russia_volga")
        # northeastern/fallback Russia
        return R("Центральная Россия", "low", "russia_fallback")

    # IBERIA
    if country == "Spain":
        if "galicia" in r: return R("Галисия", "high", "spain_region")
        if "asturias" in r: return R("Астурия", "high", "spain_region")
        if "cantabria" in r or "país vasco" in region.lower() or "pais vasco" in r: return R("Кантабрийско-Баскское побережье", "high", "spain_region")
        if "navarra" in r: return R("Наварра", "high", "spain_region")
        if "catal" in r: return R("Каталония", "high", "spain_region")
        if "valenc" in r: return R("Валенсия", "high", "spain_region")
        if "murcia" in r: return R("Мурсия", "high", "spain_region")
        if "extremadura" in r: return R("Эстремадура", "high", "spain_region")
        if "arag" in r: return R("Арагон", "high", "spain_region")
        if "castilla la mancha" in r: return R("Ла-Манча", "high", "spain_region")
        if "castilla y le" in r:
            if n in {"leon","zamora","salamanca"}: return R("Леон", "medium", "spain_castile")
            return R("Старая Кастилия", "medium", "spain_castile")
        if "madrid" in r: return R("Новая Кастилия", "medium", "spain_madrid")
        if "andaluc" in r:
            if n in {"seville","sevilla","cadiz","cádiz","huelva","cordoba","córdoba"}: return R("Нижняя Андалусия", "high", "spain_andalusia")
            return R("Верхняя Андалусия", "high", "spain_andalusia")
        if "balear" in r or "balear" in n: return R("Балеарские острова", "high", "spain_islands")
        return R("Старая Кастилия", "low", "spain_fallback")
    if country == "Portugal":
        # NE region is often NUTS / districts; latitude gives a robust first pass.
        if "azores" in n or "madeira" in n: return R("Алгарве", "low", "portugal_islands_fallback")
        if lat > 41.2 and lon > -8.4: return R("Траз-уш-Монтиш", "medium", "portugal_geo")
        if lat > 40.8: return R("Минью", "medium", "portugal_geo")
        if lat > 39.5 and lon < -8.0: return R("Бейра-Литорал", "medium", "portugal_geo")
        if lat > 39.2: return R("Бейра-Интериор", "medium", "portugal_geo")
        if lat > 38.3 and lon < -8.0: return R("Эштремадура-и-Рибатежу", "medium", "portugal_geo")
        if lat < 37.5: return R("Алгарве", "high", "portugal_geo")
        return R("Алентежу", "medium", "portugal_geo")

    # FRANCE
    if country == "France":
        rl = region.lower()
        if "île-de-france" in rl or "ile-de-france" in rl: return R("Иль-де-Франс", "high", "france_modern_region")
        if "normandie" in rl: return R("Нормандия", "high", "france_modern_region")
        if "bretagne" in rl: return R("Бретань", "high", "france_modern_region")
        if "hauts-de-france" in rl: return R("Пикардия и Артуа", "high", "france_modern_region")
        if "grand est" in rl:
            if lon > 6: return R("Эльзас и Лотарингия", "medium", "france_grand_est")
            return R("Шампань", "medium", "france_grand_est")
        if "bourgogne" in rl: return R("Бургундия", "high", "france_modern_region")
        if "pays de la loire" in rl or "centre-val de loire" in rl: return R("Долина Луары", "high", "france_modern_region")
        if "nouvelle-aquitaine" in rl: return R("Аквитания и Гасконь", "high", "france_modern_region")
        if "occitanie" in rl: return R("Лангедок", "medium", "france_modern_region")
        if "provence" in rl: return R("Прованс", "high", "france_modern_region")
        if "auvergne-rhône-alpes" in rl or "auvergne-rhone-alpes" in rl: return R("Савойя и Дофине", "medium", "france_modern_region")
        return macro_median(by_macro,"Франция"), "low", "france_macro_fallback"

    # ITALY
    if country == "Italy":
        rl = region.lower(); nl=n
        if any(x in rl for x in ["lombard"]): return R("Ломбардия","high","italy_region")
        if "piemonte" in rl or "piedmont" in rl: return R("Пьемонт","high","italy_region")
        if "ligur" in rl: return R("Лигурия","high","italy_region")
        if "veneto" in rl or "friuli" in rl: return R("Венето и Фриули","high","italy_region")
        if "emilia" in rl: return R("Эмилия-Романья","high","italy_region")
        if "tosc" in rl: return R("Тоскана","high","italy_region")
        if "lazio" in rl: return R("Папская область","high","italy_region")
        if "abruz" in rl or "marche" in rl: return R("Абруцци и Марке","high","italy_region")
        if "campan" in rl: return R("Кампания","high","italy_region")
        if "puglia" in rl or "basilic" in rl: return R("Апулия и Базиликата","high","italy_region")
        if "calabr" in rl: return R("Калабрия","high","italy_region")
        if "sicil" in rl: return R("Сицилия","high","italy_region")
        if "sard" in rl: return R("Сардиния и Корсика","high","italy_region")
        return macro_median(by_macro,"Италия"),"low","italy_fallback"

    # SCANDINAVIA
    if country == "Denmark": return R("Дания","high","country")
    if country == "Sweden": return R("Северная Скандинавия" if lat>62 else ("Центральная Швеция" if lat>58.5 else "Южная Швеция"),"high","lat_band")
    if country == "Norway": return R("Северная Норвегия" if lat>63 else "Южная Норвегия","high","lat_band")
    if country in {"Finland","Aland"}: return R("Северная Финляндия" if lat>64 else "Южная Финляндия","high","lat_band")

    # CHINA
    if country in {"China","Hong Kong S.A.R.","Macau S.A.R","Taiwan"}:
        if country in {"Hong Kong S.A.R.","Macau S.A.R"}: return R("Южнокитайское побережье","high","china_coast")
        if country == "Taiwan": return R("Южнокитайское побережье","medium","taiwan_proxy")
        if n == "shandong": return R("Шаньдун","high","china_province")
        if n in {"shanghai","jiangsu","zhejiang"}: return R("Дельта Янцзы","high","china_province")
        if n in {"sichuan","chongqing"}: return R("Сычуаньская котловина","high","china_province")
        if n in {"yunnan","guizhou","guangxi"}: return R("Юньнань и Гуйчжоу","high","china_province")
        if n in {"liaoning","jilin","heilongjiang"}: return R("Маньчжурия","high","china_province")
        if "inner mongol" in n: return R("Внутренняя Монголия","high","china_province")
        if n == "xinjiang": return R("Такла-Макан и Джунгария","high","china_province")
        if n in {"xizang","tibet","qinghai"}: return R("Тибет","high","china_province")
        if n in {"shaanxi","shanxi","ningxia","gansu"}: return R("Лёссовое плато","high","china_province")
        if n in {"guangdong","hainan","fujian"}: return R("Южнокитайское побережье","high","china_province")
        if n in {"hubei","hunan","jiangxi","anhui"}: return R("Средняя Янцзы","medium","china_province")
        if n in {"henan","hebei","beijing","tianjin"}: return R("Северокитайская равнина","high","china_province")
        return macro_median(by_macro,"Китай"),"low","china_fallback"

    # INDIA / BANGLADESH / NEPAL / BHUTAN / SRI LANKA
    if country == "India":
        if n in {"punjab","haryana","chandigarh"}: return R("Пенджаб","high","india_state")
        if n in {"uttar pradesh","uttarakhand","delhi"}: return R("Верхняя Гангская равнина","high","india_state")
        if n in {"bihar","jharkhand"}: return R("Средняя Гангская равнина","high","india_state")
        if n == "west bengal": return R("Бенгальская дельта","high","india_state")
        if n == "rajasthan": return R("Раджастхан","high","india_state")
        if n in {"gujarat","dadra and nagar haveli and daman and diu"}: return R("Гуджарат","high","india_state")
        if n in {"maharashtra","karnataka","telangana","andhra pradesh","goa"}: return R("Декан","medium","india_state")
        if n == "kerala": return R("Малабарское побережье","high","india_state")
        if n in {"tamil nadu","puducherry"}: return R("Тамильское побережье","high","india_state")
        if n in {"madhya pradesh","chhattisgarh","odisha"}: return R("Центральная Индия","medium","india_state")
        if region == "Northeast" or n in {"assam","meghalaya","tripura","manipur","mizoram","nagaland","arunachal pradesh"}: return R("Ассам и Брахмапутра","medium","india_ne")
        if n in {"himachal pradesh","jammu and kashmir","ladakh","sikkim"}: return R("Гималаи","high","india_himalaya")
        return macro_median(by_macro,"Индия"),"low","india_fallback"
    if country == "Bangladesh": return R("Бенгальская дельта","high","country")
    if country in {"Nepal","Bhutan","Siachen Glacier"}: return R("Гималаи","high","country")
    if country in {"Sri Lanka","Maldives"}: return R("Тамильское побережье","low","regional_proxy")

    # JAPAN
    if country == "Japan":
        # Prefecture names; broad latitude/longitude bands are sufficient for this layer.
        if n == "hokkaido": return R("Хоккайдо","high","japan_pref")
        if lat > 38: return R("Северный Хонсю","medium","japan_lat")
        if lon > 139 and 34.5 < lat < 37.5: return R("Канто","medium","japan_geo")
        if lon < 135.8 and lat < 35.5: return R("Кюсю и Сикоку","medium","japan_geo")
        if 134.5 <= lon <= 137.5 and 33.5 <= lat <= 36.0: return R("Кансай","medium","japan_geo")
        return R("Центральный Хонсю","medium","japan_geo")

    # UNITED STATES
    if country == "United States of America":
        if n == "alaska": return R("Аляска","high","us_state")
        if n in {"maine","new hampshire","vermont","massachusetts","connecticut","rhode island"}: return R("Новая Англия","high","us_state")
        if n in {"new york","new jersey","pennsylvania","delaware","maryland","district of columbia"}: return R("Среднеатлантическое побережье","medium","us_state")
        if n in {"west virginia","kentucky","tennessee"}: return R("Аппалачи","medium","us_state")
        if n in {"virginia","north carolina","south carolina","georgia","alabama","mississippi"}: return R("Юго-Восток США","medium","us_state")
        if n == "florida": return R("Флорида","high","us_state")
        if n in {"michigan","wisconsin","illinois","indiana","ohio","minnesota"}: return R("Район Великих озёр","medium","us_state")
        if n in {"louisiana","arkansas","missouri","iowa"}: return R("Долина Миссисипи","medium","us_state")
        if n in {"north dakota","south dakota","nebraska","kansas","oklahoma"}: return R("Великие равнины","high","us_state")
        if n == "texas": return R("Техас и нижний Рио-Гранде","high","us_state")
        if n in {"montana","wyoming","colorado","idaho"}: return R("Скалистые горы","high","us_state")
        if n in {"utah","nevada"}: return R("Межгорный Запад","high","us_state")
        if n in {"arizona","new mexico"}: return R("Юго-Западные пустыни","high","us_state")
        if n == "california": return R("Калифорнийское побережье","high","us_state")
        if n in {"washington","oregon"}: return R("Тихоокеанский Северо-Запад","high","us_state")
        return macro_median(by_macro,"Центр Северной Америки"),"low","us_fallback"

    # CANADA
    if country in {"Canada","Greenland"}:
        if country == "Greenland": return R("Арктическая Канада","low","greenland_proxy")
        if n in {"british columbia"}: return R("Британская Колумбия","high","canada_province")
        if n in {"alberta","saskatchewan","manitoba"}: return R("Канадские прерии","high","canada_province")
        if n in {"ontario","quebec"} and lat < 51: return R("Канадский населённый коридор","medium","canada_geo")
        if n in {"newfoundland and labrador"} or (n=="quebec" and lat>=51): return R("Лабрадор и север Квебека","high","canada_geo")
        if n in {"yukon","northwest territories","nunavut"}: return R("Арктическая Канада","high","canada_province")
        return R("Канадский щит","medium","canada_fallback")

    # MEXICO
    if country == "Mexico":
        if n in {"yucatán","yucatan","quintana roo","campeche"}: return R("Юкатан","high","mex_state")
        if lat > 25: return R("Северная Мексика","medium","mex_lat")
        if lon < -102 and lat < 25: return R("Тихоокеанское побережье Мексики","medium","mex_geo")
        if lon > -98 and lat < 24: return R("Мексиканское побережье Мексиканского залива","medium","mex_geo")
        return R("Центральная Мексика","medium","mex_geo")

    # BRAZIL
    if country == "Brazil":
        if n in {"rio grande do sul","santa catarina","paraná","parana"}: return R("Южная Бразилия","high","brazil_state")
        if n in {"são paulo","sao paulo","rio de janeiro","minas gerais","espírito santo","espirito santo"}: return R("Юго-Восточная Бразилия","high","brazil_state")
        if n in {"mato grosso do sul"}: return R("Пантанал","medium","brazil_state")
        if n in {"goiás","goias","distrito federal","tocantins","mato grosso"}: return R("Бразильское внутреннее плато","medium","brazil_state")
        if n in {"bahia","sergipe","alagoas","pernambuco","paraíba","paraiba","rio grande do norte","ceará","ceara","piauí","piaui","maranhão","maranhao"}: return R("Северо-Восточная Бразилия","high","brazil_state")
        if n in {"amazonas","acre","rondônia","rondonia","pará","para","amapá","amapa","roraima"}: return R("Амазонская сельва","high","brazil_amazon")
        return macro_median(by_macro,"Бразилия"),"low","brazil_fallback"

    # ANDES / SOUTH AMERICA
    if country == "Argentina":
        if lat < -45: return R("Патагония","high","argentina_lat")
        if lon < -66 and lat < -30: return R("Южные Анды","medium","argentina_west")
        if n in {"entre ríos","entre rios","corrientes","misiones"}: return R("Месопотамия Южной Америки","high","argentina_state")
        if n in {"chaco","formosa","santiago del estero"}: return R("Гран-Чако","medium","argentina_state")
        return R("Пампа","medium","argentina_default")
    if country == "Chile":
        return R("Южные Анды" if lat < -38 else "Центральное Чили","medium","chile_lat")
    if country == "Peru":
        return R("Перуанское побережье" if lon < -76 and lat > -18 else "Перуанские Анды","medium","peru_geo")
    if country == "Bolivia": return R("Альтиплано","medium","country")
    if country == "Ecuador": return R("Эквадорские Анды","medium","country")
    if country == "Colombia": return R("Карибское побережье Новой Гранады" if lat>8 else "Колумбийские Анды","medium","colombia_geo")
    if country == "Venezuela": return R("Венесуэльские Льянос","medium","country")
    if country in {"Guyana","Suriname"}: return R("Гвианское нагорье","medium","country")
    if country == "Paraguay": return R("Гран-Чако","medium","country")
    if country == "Uruguay": return R("Пампа","medium","country")

    # AUSTRALIA / NZ / PNG
    if country == "Australia":
        if n == "tasmania": return R("Тасмания","high","aus_state")
        if n in {"new south wales","victoria","australian capital territory"}: return R("Юго-Восточная Австралия","high","aus_state")
        if n == "queensland" and lon>145: return R("Восточное побережье Австралии","medium","aus_state")
        if n == "western australia" and lat < -28: return R("Юго-Западная Австралия","medium","aus_state")
        if n in {"northern territory"} or lat > -20: return R("Северная Австралия","medium","aus_geo")
        return R("Внутренняя Австралия","medium","aus_default")
    if country == "New Zealand": return R("Северный остров Новой Зеландии" if lat>-41.5 else "Южный остров Новой Зеландии","high","nz_lat")
    if country == "Papua New Guinea": return R("Высокогорья Новой Гвинеи" if "highland" in r or "highland" in n else "Побережье Новой Гвинеи","medium","png_region")

    # AFRICA: country-level macro + latitude / coast proxies for very heterogeneous areas.
    if country == "Egypt":
        if lon < 32 and lat < 31.5 and lon > 29: return R("Долина Нила" if lat < 29.5 else "Дельта Нила","medium","egypt_nile")
        return R("Сахара","medium","egypt_desert")
    if country in {"Libya","Algeria","Morocco","Tunisia","Western Sahara"}:
        if lat < 27: return R("Сахара","high","north_africa_lat")
        if country=="Morocco": return R("Марокканское побережье","medium","country")
        if country=="Algeria": return R("Алжирское побережье","medium","country")
        if country=="Tunisia": return R("Ифрикия","medium","country")
        if country=="Libya": return R("Киренаика","medium","country")
    if country == "Madagascar": return R("Мадагаскарское нагорье" if 44 < lon < 48 else "Мадагаскарское побережье","medium","madagascar_geo")

    # Broad macro resolver from catalog median.
    macro = COUNTRY_MACRO.get(country)
    if macro:
        return macro_median(by_macro, macro), "low", "macro_median"

    # Geographic fallback: always select a REAL profile row from the catalog.
    # This is intentionally marked low confidence for review.
    if lon < -30:
        if lat > 15: return choose_region(by_region,"Великие равнины"), "low", "geo_fallback_america_n"
        return choose_region(by_region,"Пампа"), "low", "geo_fallback_america_s"
    if -25 <= lon <= 55 and lat > 35:
        return choose_region(by_region,"Венгерская низменность"), "low", "geo_fallback_europe"
    if -25 <= lon <= 60 and -38 <= lat <= 35:
        return choose_region(by_region,"Кенийское нагорье"), "low", "geo_fallback_africa"
    if lon >= 110 and lat < -8:
        return choose_region(by_region,"Восточное побережье Австралии"), "low", "geo_fallback_oceania"
    return choose_region(by_region,"Центральная Анатолия"), "low", "geo_fallback_asia"


def local_laea(geom):
    rp = geom.representative_point()
    lon0, lat0 = float(rp.x), float(rp.y)
    crs = CRS.from_proj4(f"+proj=laea +lat_0={lat0:.8f} +lon_0={lon0:.8f} +datum=WGS84 +units=m +no_defs")
    fwd = Transformer.from_crs("EPSG:4326", crs, always_xy=True).transform
    inv = Transformer.from_crs(crs, "EPSG:4326", always_xy=True).transform
    return fwd, inv


def polygon_metrics(geom4326, coast_index=None):
    fwd, _ = local_laea(geom4326)
    g = make_valid(shp_transform(fwd, geom4326))
    if g.is_empty:
        return 0.0, 1.0, 1.0, 1.0, 1, 1.0
    area = g.area / 1e6
    perim = max(g.length, 1.0)
    compactness = float(np.clip(4*math.pi*g.area/(perim*perim), 0, 1))
    convexity = float(np.clip(g.area / max(g.convex_hull.area, 1.0), 0, 1))
    mrr = g.minimum_rotated_rectangle
    coords = list(mrr.exterior.coords)
    edges = [math.hypot(coords[i+1][0]-coords[i][0], coords[i+1][1]-coords[i][1]) for i in range(4)]
    edges = sorted([e for e in edges if e>0])
    elong = edges[-1]/max(edges[0],1.0) if edges else 1.0
    parts = len(g.geoms) if isinstance(g, MultiPolygon) else 1

    shape_factor = 1.0
    if elong > 3.0: shape_factor = max(shape_factor, 1.05)
    if convexity < 0.78: shape_factor = max(shape_factor, 1.12)
    if elong > 6.0 or convexity < 0.58: shape_factor = max(shape_factor, 1.18)

    coast_factor = 1.0
    coast_ratio = 0.0
    if parts >= 3:
        coast_factor = 1.30
    elif parts == 2:
        coast_factor = 1.12
    if coast_index is not None:
        try:
            # The coastline is derived from the same Admin-1 coverage. STRtree keeps
            # intersections local instead of comparing against the whole world boundary.
            tree, segments = coast_index
            b = geom4326.boundary
            idxs = tree.query(b)
            c_len = 0.0
            for j in idxs:
                inter = b.intersection(segments[int(j)])
                if not inter.is_empty:
                    c_len += inter.length
            coast_ratio = c_len / max(b.length, 1e-9)
            if coast_ratio > 0.50: coast_factor = max(coast_factor, 1.20)
            elif coast_ratio > 0.20: coast_factor = max(coast_factor, 1.12)
            elif coast_ratio > 0.025: coast_factor = max(coast_factor, 1.05)
        except Exception:
            pass
    return area, coast_factor, shape_factor, compactness, parts, coast_ratio


def round_half_up(x: float) -> int:
    return int(math.floor(x + 0.5))


def compute_count(area_km2, profile: Profile, coast_factor, shape_factor):
    relief_factor = 1.0  # Project rule: terrain does not exist at this stage.
    complexity = float(np.clip(coast_factor * relief_factor * shape_factor, 0.85, 1.35))
    area_count = max(1, round_half_up((area_km2 / max(profile.target_km2, 1e-9)) * complexity))
    final_count = max(area_count, profile.min_cells)
    final_count = min(final_count, profile.max_cells)
    return complexity, area_count, final_count


def _nearest_mask_pixel(mask, y, x):
    h,w=mask.shape
    iy=int(np.clip(round(y),0,h-1)); ix=int(np.clip(round(x),0,w-1))
    if mask[iy,ix]: return iy,ix
    yy,xx=np.nonzero(mask)
    j=np.argmin((yy-iy)**2+(xx-ix)**2)
    return int(yy[j]),int(xx[j])


def farthest_seeds(mask, n, rng):
    yy,xx=np.nonzero(mask)
    pts=np.column_stack([yy,xx]).astype(float)
    cy,cx=pts.mean(axis=0)
    j=int(np.argmin((pts[:,0]-cy)**2+(pts[:,1]-cx)**2))
    seeds=[pts[j]]
    d2=(pts[:,0]-pts[j,0])**2+(pts[:,1]-pts[j,1])**2
    for _ in range(1,n):
        # tiny deterministic jitter avoids symmetric ties.
        score=d2*(1.0+rng.random(len(d2))*1e-5)
        j=int(np.argmax(score))
        seeds.append(pts[j])
        nd2=(pts[:,0]-pts[j,0])**2+(pts[:,1]-pts[j,1])**2
        d2=np.minimum(d2,nd2)
    return np.array(seeds,dtype=float)


def smooth_displacement(mask, rng, geo_complexity=1.0):
    h,w=mask.shape
    base=max(2.0,min(h,w)*0.055)
    large=max(base*2.4,5.0)
    dx = 0.72*ndimage.gaussian_filter(rng.normal(size=(h,w)), base) + 0.28*ndimage.gaussian_filter(rng.normal(size=(h,w)), large)
    dy = 0.72*ndimage.gaussian_filter(rng.normal(size=(h,w)), base) + 0.28*ndimage.gaussian_filter(rng.normal(size=(h,w)), large)
    for a in (dx,dy):
        a -= np.mean(a[mask])
    sx=max(np.std(dx[mask]),1e-9); sy=max(np.std(dy[mask]),1e-9)
    dx/=sx; dy/=sy
    amp=min(h,w)*(0.035 + 0.035*float(np.clip(geo_complexity-0.9,0,0.5))/0.5)
    return dy*amp, dx*amp


def assign_warped(mask, seeds, disp_y, disp_x):
    yy,xx=np.nonzero(mask)
    pts=np.column_stack([yy+disp_y[yy,xx], xx+disp_x[yy,xx]])
    sy=np.clip(np.rint(seeds[:,0]).astype(int),0,mask.shape[0]-1)
    sx=np.clip(np.rint(seeds[:,1]).astype(int),0,mask.shape[1]-1)
    seed_pts=np.column_stack([seeds[:,0]+disp_y[sy,sx], seeds[:,1]+disp_x[sy,sx]])
    tree=cKDTree(seed_pts)
    _,lab=tree.query(pts,k=1)
    out=np.zeros(mask.shape,dtype=np.int16)
    out[yy,xx]=lab.astype(np.int16)+1
    return out


def lloyd(mask, seeds, disp_y, disp_x, iters=4):
    s=seeds.copy()
    for _ in range(iters):
        labels=assign_warped(mask,s,disp_y,disp_x)
        ns=[]
        for k in range(1,len(s)+1):
            yy,xx=np.nonzero(labels==k)
            if len(yy)==0:
                ns.append(s[k-1]); continue
            cy=float(np.mean(yy)); cx=float(np.mean(xx))
            iy,ix=_nearest_mask_pixel(mask,cy,cx)
            ns.append([0.65*iy+0.35*s[k-1,0],0.65*ix+0.35*s[k-1,1]])
        s=np.array(ns)
    return s,assign_warped(mask,s,disp_y,disp_x)


def cleanup_labels(labels, mask, n, max_passes=3):
    out=labels.copy()
    structure=np.array([[0,1,0],[1,1,1],[0,1,0]],dtype=np.uint8)
    for _ in range(max_passes):
        changed=False
        for k in range(1,n+1):
            cc,num=ndimage.label(out==k,structure=structure)
            if num<=1: continue
            sizes=np.bincount(cc.ravel())
            keep=1+int(np.argmax(sizes[1:]))
            for comp in range(1,num+1):
                if comp==keep: continue
                pix=(cc==comp)
                # Reassign to the most common neighboring zone.
                ring=ndimage.binary_dilation(pix,structure=structure)&(~pix)&mask
                neigh=out[ring]
                neigh=neigh[(neigh>0)&(neigh!=k)]
                if len(neigh):
                    target=int(np.bincount(neigh).argmax())
                    out[pix]=target
                    changed=True
        if not changed: break
    return out


def label_quality(labels,mask,n):
    counts=np.array([(labels==k).sum() for k in range(1,n+1)],dtype=float)
    if np.any(counts==0): return 999.0,0.0,999.0,False
    mean=counts.mean(); ratios=counts/mean
    connected=True
    for k in range(1,n+1):
        if ndimage.label(labels==k)[1] > 1:
            connected=False; break
    score=float(np.std(ratios)+max(0,0.55-ratios.min())*4+max(0,ratios.max()-1.65)*3+(0 if connected else 3))
    return score,float(ratios.min()),float(ratios.max()),connected


def make_watershed_candidate(mask,seeds,base_labels,rng,geo_complexity):
    h,w=mask.shape
    # Smooth procedural elevation; shared barriers keep watershed near the balanced CVT partition.
    sigma1=max(1.5,min(h,w)*0.018)
    sigma2=max(4.0,min(h,w)*0.065)
    z=0.67*ndimage.gaussian_filter(rng.normal(size=(h,w)),sigma1)+0.33*ndimage.gaussian_filter(rng.normal(size=(h,w)),sigma2)
    z=(z-np.mean(z[mask]))/max(np.std(z[mask]),1e-9)
    boundary=find_boundaries(base_labels,mode="thick")&mask
    barrier=ndimage.gaussian_filter(boundary.astype(float),sigma=max(1.2,min(h,w)*0.010))
    barrier/=max(float(barrier.max()),1e-9)
    elev=0.48*z + (0.90+0.35*(geo_complexity-1.0))*barrier
    markers=np.zeros(mask.shape,dtype=np.int16)
    for i,(y,x) in enumerate(seeds,1):
        iy,ix=_nearest_mask_pixel(mask,y,x)
        markers[iy,ix]=i
    lab=watershed(elev,markers=markers,mask=mask,connectivity=1,compactness=0.0).astype(np.int16)
    return lab


def raster_params(g,res_long,n):
    minx,miny,maxx,maxy=g.bounds
    W=maxx-minx; H=maxy-miny
    if W<=0 or H<=0: raise ValueError("degenerate bounds")
    long_target=max(100,min(280,int(res_long+7*n)))
    pix=max(W,H)/long_target
    # Don't let the short dimension collapse; cap the long dimension at 420 px.
    short=min(W,H)/pix
    if short<42:
        pix=min(W,H)/42.0
    if max(W,H)/pix>420:
        pix=max(W,H)/420.0
    width=max(1,int(math.ceil(W/pix))); height=max(1,int(math.ceil(H/pix)))
    transform=Affine(pix,0,minx,0,-pix,maxy)
    return transform,width,height,pix


def extract_polygons(local_parent,labels,transform,n,pix):
    geoms=[None]*n
    for gj,val in rasterio.features.shapes(labels.astype(np.int16),mask=labels>0,transform=transform,connectivity=4):
        k=int(val)
        if not (1<=k<=n): continue
        p=shape(gj)
        geoms[k-1]=p if geoms[k-1] is None else unary_union([geoms[k-1],p])
    # all_touched=True mask guarantees raster coverage extends around parent; clip restores exact parent boundary.
    clipped=[]
    for g in geoms:
        if g is None: clipped.append(Polygon()); continue
        x=make_valid(g.intersection(local_parent))
        if isinstance(x,GeometryCollection):
            polys=[q for q in x.geoms if isinstance(q,(Polygon,MultiPolygon))]
            x=unary_union(polys) if polys else Polygon()
        clipped.append(x)
    # Coverage-aware simplification preserves matched internal edges; preserve parent boundary exactly.
    tol=max(pix*0.75,1.0)
    try:
        simp=list(coverage_simplify(np.array(clipped,dtype=object),tolerance=tol,simplify_boundary=False))
        if coverage_is_valid(np.array(simp,dtype=object)):
            clipped=simp
    except Exception:
        pass
    return clipped


def partition_polygon(geom4326,n,seed,geo_complexity=1.0,res_long=120):
    if n<=1:
        return [make_valid(geom4326)], {"method":"original","min_ratio":1.0,"max_ratio":1.0,"connected":True,"coverage_valid":True}
    fwd,inv=local_laea(geom4326)
    parent=make_valid(shp_transform(fwd,geom4326))
    transform,width,height,pix=raster_params(parent,res_long,n)
    mask=rasterio.features.rasterize([(parent,1)],out_shape=(height,width),transform=transform,fill=0,all_touched=True,dtype=np.uint8).astype(bool)
    if mask.sum()<n*8:
        # increase resolution for tiny / narrow polygons
        transform,width,height,pix=raster_params(parent,max(res_long*1.8,220),n)
        mask=rasterio.features.rasterize([(parent,1)],out_shape=(height,width),transform=transform,fill=0,all_touched=True,dtype=np.uint8).astype(bool)
    rng=np.random.default_rng(seed)
    seeds=farthest_seeds(mask,n,rng)
    dy,dx=smooth_displacement(mask,rng,geo_complexity)
    seeds,cvt=lloyd(mask,seeds,dy,dx,iters=4)
    cvt=cleanup_labels(cvt,mask,n)
    q_cvt=label_quality(cvt,mask,n)

    ws=make_watershed_candidate(mask,seeds,cvt,rng,geo_complexity)
    ws=cleanup_labels(ws,mask,n)
    q_ws=label_quality(ws,mask,n)

    # Prefer organic watershed if it remains within project area-balance limits.
    if q_ws[1]>=0.55 and q_ws[2]<=1.65 and q_ws[3] and q_ws[0] <= q_cvt[0]+0.18:
        labels=ws; method="watershed+cvt"
        q=q_ws
    else:
        labels=cvt; method="warped_cvt"
        q=q_cvt

    local_cells=extract_polygons(parent,labels,transform,n,pix)
    # Ensure all cells are valid and non-empty; rare failures fall back to CVT vectorization.
    if any(g.is_empty for g in local_cells):
        local_cells=extract_polygons(parent,cvt,transform,n,pix); method="warped_cvt_fallback"; q=q_cvt
    cov_valid=bool(coverage_is_valid(np.array(local_cells,dtype=object)))
    world=[make_valid(shp_transform(inv,g)) for g in local_cells]
    return world,{"method":method,"min_ratio":q[1],"max_ratio":q[2],"connected":q[3],"coverage_valid":cov_valid,"raster_w":width,"raster_h":height}


def adjacency_graph(cells):
    G=nx.Graph(); G.add_nodes_from(range(len(cells)))
    for i in range(len(cells)):
        for j in range(i+1,len(cells)):
            try:
                if cells[i].boundary.intersection(cells[j].boundary).length>1e-10:
                    G.add_edge(i,j)
            except Exception:
                pass
    return G


def filter_gdf(gdf, countries=None, adm1_codes=None, limit=None):
    out=gdf
    if countries:
        wanted=set(countries)
        out=out[out["admin"].isin(wanted)]
    if adm1_codes:
        wanted=set(adm1_codes)
        out=out[out["adm1_code"].isin(wanted)]
    if limit:
        out=out.head(limit)
    return out.copy()


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--input-shp",required=True)
    ap.add_argument("--profiles-json",required=True)
    ap.add_argument("--out-dir",required=True)
    ap.add_argument("--countries",nargs="*",default=None)
    ap.add_argument("--adm1",nargs="*",default=None)
    ap.add_argument("--limit",type=int,default=None)
    ap.add_argument("--resolution",type=int,default=120,help="base long-side raster pixels per Admin-1")
    ap.add_argument("--counts-only",action="store_true")
    ap.add_argument("--no-coast",action="store_true")
    args=ap.parse_args()

    outdir=Path(args.out_dir); outdir.mkdir(parents=True,exist_ok=True)
    profiles,by_region,by_macro=load_profiles(args.profiles_json)
    gdf=gpd.read_file(args.input_shp)
    gdf=gdf[gdf.geometry.notna() & (~gdf.geometry.is_empty)].copy()
    work=filter_gdf(gdf,args.countries,args.adm1,args.limit)

    coast_index=None
    if not args.no_coast:
        print("[1/5] Building indexed world coastline from Admin-1 coverage…",flush=True)
        try:
            # coverage_union_all is much faster than a generic unary union for edge-matched Admin-1 data.
            import shapely
            valid_arr=shapely.make_valid(gdf.geometry.values)
            world_union=shapely.coverage_union_all(valid_arr)
            coastline=world_union.boundary
            segments=list(coastline.geoms) if hasattr(coastline,"geoms") else [coastline]
            coast_index=(STRtree(segments),segments)
        except Exception as e:
            print("  coastline failed; continuing without coast factor:",e,file=sys.stderr)
            coast_index=None

    print(f"[2/5] Resolving profiles/counts for {len(work)} Admin-1…",flush=True)
    meta=[]
    for idx,row in work.iterrows():
        p,conf,rule=resolve_profile(row,by_region,by_macro)
        area,coast,shape_f,compact,parts,coast_ratio=polygon_metrics(row.geometry,coast_index)
        complexity,area_count,n=compute_count(area,p,coast,shape_f)
        meta.append({
            "_idx":idx,"adm1_code":row.get("adm1_code"),"iso_3166_2":row.get("iso_3166_2"),"country":row.get("admin"),
            "name":row.get("name"),"name_en":row.get("name_en"),"name_ru":row.get("name_ru"),
            "area_km2":area,"region_profile":p.region,"macroregion":p.macroregion,"profile_id":p.profile,"target_km2":p.target_km2,
            "profile_min":p.min_cells,"profile_max":p.max_cells,"profile_confidence":conf,"profile_rule":rule,
            "coast_factor":coast,"shape_factor":shape_f,"relief_factor":1.0,"complexity":complexity,"compactness":compact,
            "parts":parts,"coast_ratio":coast_ratio,"area_count":area_count,"final_count":n,
        })

    report_path=outdir/"province_zone_counts_v1.csv"
    if meta:
        with report_path.open("w",encoding="utf-8-sig",newline="") as f:
            wr=csv.DictWriter(f,fieldnames=[k for k in meta[0].keys() if k!="_idx"])
            wr.writeheader(); wr.writerows([{k:v for k,v in m.items() if k!="_idx"} for m in meta])
    print("  count report:",report_path,flush=True)

    summary={
        "admin1_total":len(meta),
        "zones_total":int(sum(m["final_count"] for m in meta)),
        "confidence":dict((x,sum(m["profile_confidence"]==x for m in meta)) for x in ["high","medium","low"]),
        "profiles_used":len(set(m["region_profile"] for m in meta)),
        "counts_histogram":dict(sorted((int(k),int(v)) for k,v in __import__('collections').Counter(m["final_count"] for m in meta).items())),
        "relief_factor":"fixed at 1.0 by project rule; no terrain input used",
    }
    (outdir/"generation_summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")

    if args.counts_only:
        print(json.dumps(summary,ensure_ascii=False,indent=2)); return

    print(f"[3/5] Generating {summary['zones_total']} fantasy Admin-2 zones…",flush=True)
    records=[]; methods=defaultdict(int); invalid=0
    for pos,m in enumerate(meta,1):
        row=work.loc[m["_idx"]]
        p=choose_region(by_region,m["region_profile"])
        seed=stable_seed(row.get("adm1_code"),row.get("name"),m["final_count"],"fantasy_admin2_v1")
        try:
            cells,diag=partition_polygon(row.geometry,m["final_count"],seed,p.geo_complexity,args.resolution)
        except Exception as e:
            print(f"  WARN {row.get('adm1_code')} {row.get('name')}: {e}; keeping parent as one zone",file=sys.stderr)
            cells=[make_valid(row.geometry)]
            diag={"method":"error_parent","min_ratio":1.0,"max_ratio":1.0,"connected":True,"coverage_valid":True,"error":str(e)}
        methods[diag["method"]]+=1
        if not diag.get("coverage_valid",True): invalid+=1
        G=adjacency_graph(cells) if len(cells)>1 else nx.Graph([(0,0)])
        graph_connected=nx.is_connected(G) if len(cells)>1 else True
        for i,g in enumerate(cells,1):
            records.append({
                "admin2_id":f"{row.get('adm1_code')}_F{i:02d}","zone_no":i,
                "adm1_code":row.get("adm1_code"),"iso_3166_2":row.get("iso_3166_2"),"admin1_name":row.get("name"),"country":row.get("admin"),
                "region_profile":p.region,"macroregion":p.macroregion,"profile_id":p.profile,"target_km2":p.target_km2,
                "parent_area_km2":m["area_km2"],"parent_zone_count":m["final_count"],"profile_confidence":m["profile_confidence"],
                "gen_method":diag["method"],"area_balance_min":diag.get("min_ratio"),"area_balance_max":diag.get("max_ratio"),
                "zone_graph_connected":graph_connected,"coverage_valid":diag.get("coverage_valid",True),"geometry":g,
            })
        if pos%100==0 or pos==len(meta):
            print(f"  {pos}/{len(meta)} Admin-1, zones={len(records)}",flush=True)

    print("[4/5] Writing GeoPackage…",flush=True)
    outg=gpd.GeoDataFrame(records,geometry="geometry",crs="EPSG:4326")
    gpkg=outdir/"fantasy_admin2_v1.gpkg"
    outg.to_file(gpkg,layer="fantasy_admin2",driver="GPKG")
    # also GeoJSON for easy Godot/toolchain import; zip it because plain GeoJSON is large.
    geojson=outdir/"fantasy_admin2_v1.geojson"
    outg.to_file(geojson,driver="GeoJSON")
    import zipfile
    zip_path=outdir/"fantasy_admin2_v1.geojson.zip"
    with zipfile.ZipFile(zip_path,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        z.write(geojson,arcname=geojson.name)
    try: geojson.unlink()
    except Exception: pass

    summary.update({"methods":dict(methods),"invalid_coverages":invalid,"output_features":len(outg)})
    (outdir/"generation_summary.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding="utf-8")
    print("[5/5] Done")
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print(gpkg)
    print(zip_path)

if __name__=="__main__":
    main()
